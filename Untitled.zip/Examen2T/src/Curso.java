import java.util.Scanner;

//importa las bibliotecas que creas necesaria.
public class Curso {

	public static void main(String[] arg) {
		Alumno alumno1 = new Alumno("joaquinto", "pocas luces", 13);
		Alumno alumno2 = new Alumno("alvaro", "elistillo de clase", 15);
		Alumno alumno3 = new Alumno("antonio", "pedante sabelotodo", 43);
		Alumno alumno4 = new Alumno("beatriz", "aprueba todo", 23);
		Alumno alumno5 = new Alumno("carmen", "brillante brillante", 17);
		Profesor profesor1 = new Profesor("augusto", "mecargotodo", true);
		Profesor profesor2 = new Profesor("pedrito", "machacón", false);

		// crea un objeto de tipo modulo

		Modulo modulo = new Modulo("programación", 4);

		// añade los alumnos y los profesores

		modulo.setListaProfesores(profesor1);
		modulo.setListaProfesores(profesor2);
		;

		// lee desde la clase scanner el nombre del módulo
		Scanner in = new Scanner(System.in);
		nombreModulo = in.next();

		// y las horas del mismo, dichas horas deben estar comprendidas entre
		// 3 a 8
		nombreModulo.matches("") = in.next();

		// usa una expresión regular para controlar el dato introducido
		// tanto para que sea un entero y esté en ese rango de valor
		// igual con el nombre del módulo, deben ser solo letras
		// NO puede lanzarse una excepción por introducir un valor no entero
		// en el caso que la cantidad introducida no corresponda al rango
		// anterior
		// o no sea una cadena de letras el nombre del módulo
		// se establecerá 6 horas en caso de una lectura errónea
		// y DEFAULT como nombre del ciclo en caso incorrecto

		// imprime la referencia del módulo
		// imprime la lista de alumnos
		// imprime la lista alumnes menores de edad
		// imprime la lista de profesores

	}
}
